/**
 * Nacionalidade FC – Lógica principal do jogo
 */

const POSITIONS = [
  { id: "gk",  label: "GOL", css: "pos-gk" },
  { id: "lb",  label: "LE",  css: "pos-lb" },
  { id: "cb1", label: "ZAG", css: "pos-cb1" },
  { id: "cb2", label: "ZAG", css: "pos-cb2" },
  { id: "rb",  label: "LD",  css: "pos-rb" },
  { id: "cm1", label: "VOL", css: "pos-cm1" },
  { id: "cm2", label: "MEI", css: "pos-cm2" },
  { id: "cm3", label: "MEI", css: "pos-cm3" },
  { id: "lw",  label: "PE",  css: "pos-lw" },
  { id: "st",  label: "ATA", css: "pos-st" },
  { id: "rw",  label: "PD",  css: "pos-rw" }
];

const State = {
  squad: {},
  usedNations: new Set(),
  currentClub: null,
  currentYear: null,
  selectedPlayer: null,
  phase: "menu",
  rounds: 0
};

/* ========== UI ========== */
function showScreen(name) {
  document.getElementById("screen-menu").classList.toggle("hidden", name !== "menu");
  document.getElementById("screen-game").classList.toggle("hidden", name !== "game");
}

function setBadge(text) {
  const el = document.getElementById("badge");
  if (el) el.textContent = text;
}

function toast(msg, ms = 2800) {
  const t = document.createElement("div");
  t.className = "fixed bottom-6 left-1/2 -translate-x-1/2 bg-dark-700 border border-accent text-sm px-4 py-2.5 rounded-xl z-50 shadow-xl max-w-[90vw] text-center";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), ms);
}

/* ========== INIT ========== */
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("btn-start").addEventListener("click", startGame);
  document.getElementById("btn-confirm-player").addEventListener("click", confirmPlayer);
  document.getElementById("btn-resign").addEventListener("click", () => {
    if (confirm("Desistir da partida atual?")) endGame(false, "Você desistiu da partida.");
  });
  document.getElementById("btn-replay").addEventListener("click", () => location.reload());

  const input = document.getElementById("player-input");
  input.addEventListener("input", updateSuggestions);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") confirmPlayer();
  });
});

function startGame() {
  State.squad = {};
  State.usedNations = new Set();
  State.selectedPlayer = null;
  State.phase = "choosing";
  State.rounds = 0;

  showScreen("game");
  setBadge("Em jogo");
  renderPitch();
  updateNations();
  updateProgress();
  updateSquadList();
  nextDraw();
}

/* ========== SORTEIO ========== */
function nextDraw() {
  State.selectedPlayer = null;
  State.phase = "choosing";

  const input = document.getElementById("player-input");
  input.value = "";
  input.disabled = false;
  document.getElementById("btn-confirm-player").disabled = false;

  let club, year, candidates;
  let attempts = 0;

  do {
    club = CLUBS[Math.floor(Math.random() * CLUBS.length)];
    year = 2020 + Math.floor(Math.random() * 8);
    candidates = CLEAN_DB.filter(p =>
      p.club === club &&
      p.years.includes(year) &&
      !State.usedNations.has(p.nation)
    );
    attempts++;
  } while (candidates.length === 0 && attempts < 100);

  if (candidates.length === 0) {
    const free = CLEAN_DB.filter(p => !State.usedNations.has(p.nation));
    if (free.length === 0) {
      endGame(false, "Não há mais jogadores com nacionalidades disponíveis no banco.");
      return;
    }
    const pick = free[Math.floor(Math.random() * free.length)];
    club = pick.club;
    year = pick.years[Math.floor(Math.random() * pick.years.length)];
  }

  State.currentClub = club;
  State.currentYear = year;
  State.rounds++;

  document.getElementById("draw-club").textContent = club;
  document.getElementById("draw-year").textContent = year;

  updateSuggestions();
  renderPitch(false);
  toast(`${club} · ${year}`);
}

function getValidPlayers() {
  return CLEAN_DB.filter(p =>
    p.club === State.currentClub &&
    p.years.includes(State.currentYear)
  );
}

function updateSuggestions() {
  const q = document.getElementById("player-input").value.trim().toLowerCase();
  const list = document.getElementById("player-suggestions");
  list.innerHTML = "";

  const valid = getValidPlayers();
  const filtered = q
    ? valid.filter(p => p.name.toLowerCase().includes(q))
    : valid;

  filtered.slice(0, 20).forEach(p => {
    const opt = document.createElement("option");
    opt.value = p.name;
    list.appendChild(opt);
  });
}

/* ========== CONFIRMAR JOGADOR ========== */
function confirmPlayer() {
  if (State.phase !== "choosing") return;

  const name = document.getElementById("player-input").value.trim();
  if (!name) {
    toast("Digite o nome de um jogador.");
    return;
  }

  const valid = getValidPlayers();
  const player = valid.find(p => p.name.toLowerCase() === name.toLowerCase());

  if (!player) {
    toast("Jogador inválido para este clube/ano. Tente outro nome.");
    return;
  }

  if (State.usedNations.has(player.nation)) {
    endGame(false, `Nacionalidade repetida! ${player.flag} ${player.nation} já está no seu time.`);
    return;
  }

  State.selectedPlayer = player;
  State.phase = "placing";

  document.getElementById("player-input").disabled = true;
  document.getElementById("btn-confirm-player").disabled = true;

  toast(`${player.flag} ${player.name} confirmado — clique em uma posição vazia`);
  renderPitch(true);
}

/* ========== CAMPO ========== */
function renderPitch(selectable = false) {
  const container = document.getElementById("formation");
  container.innerHTML = "";

  POSITIONS.forEach(pos => {
    const div = document.createElement("div");
    div.className = `slot ${pos.css}`;
    div.dataset.pos = pos.id;

    if (State.squad[pos.id]) {
      const p = State.squad[pos.id];
      div.classList.add("filled");
      div.style.borderColor = "#22c55e";
      div.innerHTML = `
        <span class="font-bold text-white leading-tight px-0.5">${shortName(p.name)}</span>
        <span class="flag mt-0.5">${p.flag}</span>
      `;
    } else {
      div.innerHTML = `<span class="text-slate-400">${pos.label}</span>`;
      if (selectable && State.phase === "placing") {
        div.classList.add("selectable");
        div.addEventListener("click", () => placePlayer(pos.id));
      }
    }
    container.appendChild(div);
  });
}

function shortName(full) {
  const parts = full.trim().split(/\s+/);
  return parts.length <= 2 ? full : parts[parts.length - 1];
}

function placePlayer(posId) {
  if (State.phase !== "placing" || !State.selectedPlayer) return;
  if (State.squad[posId]) return;

  const player = State.selectedPlayer;
  State.squad[posId] = player;
  State.usedNations.add(player.nation);
  State.selectedPlayer = null;
  State.phase = "choosing";

  updateNations();
  updateProgress();
  updateSquadList();
  renderPitch(false);

  if (Object.keys(State.squad).length >= 11) {
    endGame(true, "Parabéns! Você montou o 4-3-3 completo sem repetir nenhuma nacionalidade.");
    return;
  }

  setTimeout(nextDraw, 700);
}

/* ========== PAINÉIS ========== */
function updateNations() {
  const el = document.getElementById("nations-list");
  if (State.usedNations.size === 0) {
    el.innerHTML = '<span class="text-xs text-slate-500">Nenhuma ainda</span>';
    return;
  }

  const flagMap = {};
  CLEAN_DB.forEach(p => {
    if (!flagMap[p.nation]) flagMap[p.nation] = p.flag;
  });

  el.innerHTML = "";
  [...State.usedNations].sort().forEach(nation => {
    const span = document.createElement("span");
    span.className = "inline-flex items-center gap-1 bg-dark-900 border border-dark-600 rounded-lg px-2 py-1 text-xs";
    span.innerHTML = `<span class="flag">${flagMap[nation] || "🏳️"}</span> ${nation}`;
    el.appendChild(span);
  });
}

function updateProgress() {
  const count = Object.keys(State.squad).length;
  document.getElementById("progress-bar").style.width = `${(count / 11) * 100}%`;
  document.getElementById("progress-text").textContent = `${count}/11`;
}

function updateSquadList() {
  const ul = document.getElementById("squad-list");
  ul.innerHTML = "";
  POSITIONS.forEach(pos => {
    const p = State.squad[pos.id];
    const li = document.createElement("li");
    li.className = "flex gap-1.5";
    if (p) {
      li.innerHTML = `<span class="text-slate-500 w-8 shrink-0">${pos.label}</span> <span>${p.flag} ${p.name}</span>`;
    } else {
      li.innerHTML = `<span class="text-slate-600">${pos.label}: —</span>`;
    }
    ul.appendChild(li);
  });
}

/* ========== FIM DE JOGO ========== */
function endGame(won, message) {
  State.phase = "ended";
  const modal = document.getElementById("modal");
  modal.classList.remove("hidden");
  modal.classList.add("flex");

  document.getElementById("modal-icon").textContent = won ? "🏆" : "💀";
  const title = document.getElementById("modal-title");
  title.textContent = won ? "Vitória!" : "Game Over";
  title.className = won
    ? "text-2xl font-extrabold mb-2 text-accent"
    : "text-2xl font-extrabold mb-2 text-red-400";

  document.getElementById("modal-msg").textContent = message;

  document.getElementById("modal-stats").innerHTML = `
    <p>Jogadores escalados: <strong class="text-white">${Object.keys(State.squad).length}/11</strong></p>
    <p>Nacionalidades usadas: <strong class="text-white">${State.usedNations.size}</strong></p>
    <p>Rodadas jogadas: <strong class="text-white">${State.rounds}</strong></p>
  `;
}
