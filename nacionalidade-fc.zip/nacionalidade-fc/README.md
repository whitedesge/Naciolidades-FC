# Nacionalidade FC

Mini-jogo interativo de futebol no estilo EA FC Ultimate Team.

**Objetivo:** Montar um time titular no esquema **1-4-3-3** usando jogadores do Brasileirão (2020–2027) **sem repetir nenhuma nacionalidade**.

---

## 🎮 Como jogar

1. Clique em **Iniciar Jogo**
2. O sistema sorteia um **clube do Brasileirão** + um **ano (2020–2027)**
3. Digite (ou selecione na lista) um jogador que atuou naquele clube naquele ano
4. Clique em **Confirmar**
5. Clique em uma **posição vazia** no campo
6. Se a nacionalidade já estiver no time → **Game Over**
7. Se for inédita → o jogador é fixado e o país é marcado como usado
8. Preencha as **11 posições** sem repetir país = **Vitória**

---

## ⚽ Formação

```
        PE          ATA          PD

        VOL         MEI         MEI

   LE      ZAG            ZAG      LD

                  GOL
```

---

## 📦 Estrutura do projeto

```
nacionalidade-fc/
├── index.html          # Página principal (SPA)
├── css/
│   └── styles.css      # Estilos do campo e complementos
├── js/
│   ├── data.js         # Banco de jogadores + clubes
│   └── game.js         # Lógica do jogo
└── README.md
```

---

## 🚀 Como publicar (GitHub Pages)

1. Crie um repositório público no GitHub (ex: `nacionalidade-fc`)
2. Faça upload de **todos os arquivos e pastas** (mantenha a estrutura)
3. Vá em **Settings → Pages**
4. Em **Source** escolha a branch `main` e a pasta `/ (root)`
5. Clique em **Save**
6. Acesse: `https://SEU-USUARIO.github.io/nacionalidade-fc/`

Também funciona perfeitamente no **Netlify** e **Vercel** (só arrastar a pasta).

---

## 🛠️ Tecnologias

- HTML5
- Tailwind CSS (via CDN)
- CSS customizado (campo visual)
- JavaScript vanilla (sem frameworks)
- 100% estático — sem backend

---

## 📊 Banco de dados

Mais de **180 jogadores** reais/realistas de clubes do Brasileirão (Flamengo, Palmeiras, Corinthians, São Paulo, Grêmio, Internacional, Atlético-MG, Fluminense, Botafogo, Vasco, Bahia, Fortaleza, Athletico-PR etc.), com:

- Nome
- Clube
- Anos em que atuou (2020–2027)
- Nacionalidade + bandeira

---

## 🎨 Visual

Dark mode inspirado no EA FC Ultimate Team, com:

- Campo de futebol visual
- Cards de sorteio
- Lista de nacionalidades usadas
- Progresso e elenco atual
- Modal de vitória / derrota

---

Feito para ser jogado no celular ou desktop. Divirta-se! 🌍⚽
